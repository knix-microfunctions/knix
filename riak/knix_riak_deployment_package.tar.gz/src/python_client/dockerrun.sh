pip3 install --upgrade pip
pip3 install riak
echo "RUN: python3 RiakClient.py"
bash
