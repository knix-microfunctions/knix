#   Copyright 2020 The KNIX Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import qrcode
import base64
import json
from io import BytesIO
from PIL import Image

def handle(event, context):

    # Check if function input JSON contains targetURL field
    if 'targetURL' not in event:
        raise ValueError("No 'targetURL' field in JSON input data")

    # Create QR code for target URL
    img = qrcode.make(event['targetURL'])

    # Save qrcode output as JPG image
    buffered = BytesIO()
    img.save(buffered, format="JPEG")

    # base64-encode img data
    qr_b64 = base64.b64encode(buffered.getvalue()).decode()

    # Store img in MicroFunctions object store
    context.put('qrcode.jpg', qr_b64)

    # Log status
    context.log("Saved QR code image as qrcode.jpg to object store")

    # Return HTML snippet with img data encoded inline
    return "<img src='data:image/jpeg;base64," + qr_b64 + "';>"
