#   Copyright 2020 The KNIX Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import json
import re

def handle(event, context):

    return_str = ""

    if ("Translation" in event[0]):
        italian_tts = context.get("it-IT.mp3")
        italian_tr = re.sub(r"\\u([0-9a-fA-F]{4})", r"&#x\1;", json.dumps(event[0]['Translation']).strip('"'))
        return_str += "<p> <b>Italian:</b> " + italian_tr + "<br><br><audio controls><source src='data:audio/mp3;base64," + italian_tts + "' type='audio/mp3'></audio>"

    if ("Translation" in event[1]):
        french_tts = context.get("fr-FR.mp3")
        french_tr = re.sub(r"\\u([0-9a-fA-F]{4})", r"&#x\1;", json.dumps(event[1]['Translation']).strip('"'))
        return_str += "<p> <b>French:</b> " + french_tr + "<br><br><audio controls><source src='data:audio/mp3;base64," + french_tts + "' type='audio/mp3'></audio>"

    if ("Translation" in event[2]):
        german_tts = context.get("de-DE.mp3")
        german_tr = re.sub(r"\\u([0-9a-fA-F]{4})", r"&#x\1;", json.dumps(event[2]['Translation']).strip('"'))
        return_str += "<p> <b>German:</b> " + german_tr + "<br><br><audio controls><source src='data:audio/mp3;base64," + german_tts + "' type='audio/mp3'></audio>"

    return return_str
