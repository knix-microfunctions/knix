/**
 * @author v.lugovsky
 * created on 15.12.2015
 */
(function () {
  'use strict';

  angular.module('BlurAdmin.theme', [
      'toastr',
      'textAngular',
      'BlurAdmin.theme.components',
      'BlurAdmin.theme.inputs'
  ]);

})();
