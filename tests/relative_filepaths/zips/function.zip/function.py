
import os

content = ""

try:
    curdir = os.path.dirname(__file__)
    print("function's current directory: " + curdir)
    with open("data.txt", "r") as f:
        content = f.readlines()
    content = ''.join(content).strip()
except Exception as exc:
    content = "It didn't work."
    #raise exc


def handle(event, context):

    return content
